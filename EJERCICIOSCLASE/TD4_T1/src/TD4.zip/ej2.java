import java.awt.*;

public class ej2 {
    public class SomethingIsWrong {
        public static void main(String[] args) {
            algomalo();

        }
        public static void algomalo(){
            Rectangle myRect = new Rectangle();
            myRect.width = 40;
            myRect.height = 50;
            System.out.print ("myRect's area is " + myRect.width*myRect.height);

        }
    }
}
