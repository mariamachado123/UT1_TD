public class ej6_a {
    public static void main(String[] args) {
        String subcadena="Hola Mundo";
        System.out.println(subcadena.substring(0, 4));
        System.out.println(subcadena.substring(5));
    }
}
