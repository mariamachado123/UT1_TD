public class ej6_eYf {
    public static void main(String[] args) {
        String palabra="HOLA MUNDO";
        System.out.println(palabra.toLowerCase());
        String palabra2="hola mundo";
        System.out.println(palabra2.toUpperCase());
    }
}
