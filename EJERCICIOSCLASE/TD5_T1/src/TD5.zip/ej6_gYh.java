public class ej6_gYh {
    public static void main(String[] args) {
        String palabra="hola mundo";
        System.out.println(palabra.indexOf("u"));
        String palabra2="hola mundo mundo";
        System.out.println(palabra2.lastIndexOf("do"));
    }
}
