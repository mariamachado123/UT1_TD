public class ej6_b {
    public static void main(String[] args) {
        String dividido="H,o,l,a,M,u,n,d,o";
        String[] partes=dividido.split(",");
        for(int i=0;i<partes.length;i++){
            System.out.println(partes[i]);

        }
    }
}
