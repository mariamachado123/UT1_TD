public class ej6_c {
    public static void main(String[] args) {
        String palabra="Hola Mundo";
        System.out.println(palabra.subSequence(0, 4));

    }
}
