public class ej6_d {
    public static void main(String[] args) {
        String palabra="  Hola Mundo  ";
        System.out.println(palabra);
        System.out.println(palabra.trim());
    }
}
