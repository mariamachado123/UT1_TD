public class ej6_i {
    public static void main(String[] args) {
        String palabra="Hola Mundo";
        System.out.println(palabra.contains("Mundo"));
        System.out.println(palabra.contains("Dia"));
    }
}
